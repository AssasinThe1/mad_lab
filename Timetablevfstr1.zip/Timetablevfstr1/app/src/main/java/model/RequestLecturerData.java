package model;

public class RequestLecturerData {
    private String lecturer;

    public RequestLecturerData(String lecturer) {
        this.lecturer = lecturer;
    }

    public String getLecturer() {
        return lecturer;
    }
}
