package model;

public class FreeLecturersRequest {
    private String day;
    private String time;

    public FreeLecturersRequest(String day, String time) {
        this.day = day;
        this.time = time;
    }

    // Getters and setters
    // ...
}